import React from 'react'

const home = () => {
  return (
    <div>
      <h1>home</h1>

    </div>
  )
}

export default home
